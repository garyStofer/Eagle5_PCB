var searchData=
[
  ['servo_5finit',['servo_init',['../group__Servo.html#ga1cebb38b9d7b43f6d6d026f10eb46e5b',1,'littleWire']]],
  ['servo_5fupdatelocation',['servo_updateLocation',['../group__Servo.html#gab0656f06cf8e73d91ae4b1e5148da4e9',1,'littleWire']]],
  ['spi_5finit',['spi_init',['../group__SPI.html#ga5ccf0433ba234ff754d8c8c18009684a',1,'littleWire']]],
  ['spi_5fsendmessage',['spi_sendMessage',['../group__SPI.html#ga842fef3abf87f0e5afcc5406609f4858',1,'littleWire']]],
  ['spi_5fsendmessagemulti',['spi_sendMessageMulti',['../group__SPI.html#ga5f31e9d5d09a0175a60414c8755f67d1',1,'littleWire']]],
  ['spi_5fupdatedelay',['spi_updateDelay',['../group__SPI.html#ga8205ede07ac2bb5b8062a288a46d9591',1,'littleWire']]]
];
