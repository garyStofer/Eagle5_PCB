var searchData=
[
  ['readfirmwareversion',['readFirmwareVersion',['../classlittleWire.html#abd208452c78384fa4b7323ad5038f3bd',1,'littleWire']]]
];
